CREATE TABLE [dbo].[Receivers] (

	[Receiver_ID] int NOT NULL, 
	[Name] varchar(255) NULL, 
	[Type] varchar(100) NULL, 
	[City] varchar(100) NULL, 
	[Contact] varchar(100) NULL
);


GO
ALTER TABLE [dbo].[Receivers] ADD CONSTRAINT PK_Receivers primary key NONCLUSTERED ([Receiver_ID]);