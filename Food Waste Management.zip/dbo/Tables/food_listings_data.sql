CREATE TABLE [dbo].[food_listings_data] (

	[Food_ID] int NULL, 
	[Food_Name] varchar(50) NULL, 
	[Quantity] int NULL, 
	[Expiry_Date] date NULL, 
	[Provider_ID] int NULL, 
	[Provider_Type] varchar(50) NULL, 
	[Location] varchar(100) NULL, 
	[Food_Type] varchar(30) NULL, 
	[Meal_Type] varchar(30) NULL
);