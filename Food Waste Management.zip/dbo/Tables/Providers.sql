CREATE TABLE [dbo].[Providers] (

	[Provider_ID] int NOT NULL, 
	[Name] varchar(255) NULL, 
	[Type] varchar(100) NULL, 
	[Address] varchar(500) NULL, 
	[City] varchar(100) NULL, 
	[Contact] varchar(100) NULL
);


GO
ALTER TABLE [dbo].[Providers] ADD CONSTRAINT PK_Providers primary key NONCLUSTERED ([Provider_ID]);