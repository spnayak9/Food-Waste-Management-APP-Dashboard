CREATE TABLE [dbo].[Claims] (

	[Claim_ID] int NOT NULL, 
	[Food_ID] int NULL, 
	[Receiver_ID] int NULL, 
	[Status] varchar(50) NULL, 
	[Timestamp] datetime2(3) NULL
);


GO
ALTER TABLE [dbo].[Claims] ADD CONSTRAINT PK_Claims primary key NONCLUSTERED ([Claim_ID]);
GO
ALTER TABLE [dbo].[Claims] ADD CONSTRAINT FK_Claims_Food FOREIGN KEY ([Food_ID]) REFERENCES [dbo].[Food_Listings]([Food_ID]);
GO
ALTER TABLE [dbo].[Claims] ADD CONSTRAINT FK_Claims_Receiver FOREIGN KEY ([Receiver_ID]) REFERENCES [dbo].[Receivers]([Receiver_ID]);