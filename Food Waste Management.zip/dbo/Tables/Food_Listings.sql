CREATE TABLE [dbo].[Food_Listings] (

	[Food_ID] int NOT NULL, 
	[Food_Name] varchar(255) NULL, 
	[Quantity] int NULL, 
	[Expiry_Date] date NULL, 
	[Provider_ID] int NULL, 
	[Provider_Type] varchar(100) NULL, 
	[Location] varchar(255) NULL, 
	[Food_Type] varchar(100) NULL, 
	[Meal_Type] varchar(100) NULL
);


GO
ALTER TABLE [dbo].[Food_Listings] ADD CONSTRAINT PK_Food_Listings primary key NONCLUSTERED ([Food_ID]);
GO
ALTER TABLE [dbo].[Food_Listings] ADD CONSTRAINT FK_Food_Provider FOREIGN KEY ([Provider_ID]) REFERENCES [dbo].[Providers]([Provider_ID]);