CREATE TABLE [dbo].[claims_data] (

	[Status] varchar(8000) NULL, 
	[Timestamp] datetime2(3) NULL, 
	[Claim_ID] int NULL, 
	[Food_ID] int NULL, 
	[Receiver_ID] int NULL
);