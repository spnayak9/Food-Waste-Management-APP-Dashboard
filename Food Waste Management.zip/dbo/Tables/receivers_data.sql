CREATE TABLE [dbo].[receivers_data] (

	[Name] varchar(8000) NULL, 
	[Type] varchar(8000) NULL, 
	[City] varchar(8000) NULL, 
	[Contact] varchar(8000) NULL, 
	[Receiver_ID] int NULL
);