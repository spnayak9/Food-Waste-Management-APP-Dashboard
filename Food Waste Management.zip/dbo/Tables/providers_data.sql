CREATE TABLE [dbo].[providers_data] (

	[Name] varchar(8000) NULL, 
	[Type] varchar(8000) NULL, 
	[Address] varchar(8000) NULL, 
	[City] varchar(8000) NULL, 
	[Contact] varchar(8000) NULL, 
	[Provider_ID] int NULL
);